import React, { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import Header from "./Header";
import MenuSidebar from "./MenuSidebar";
import { Column } from "primereact/column";
import Deepak from './tableData.json';

export default function RTOtable() {
  const [dataTable, setdataTable] = useState([]);
  const data = [
    { name: "firstName", value: "Deepak", age: "24" },
    { name: "firstName", value: "Deepu", age: "25" },
    { name: "firstName", value: "Vikas", age: "26" },
    { name: "firstName", value: "Vishal", age: "27" },
  ];

  const columns = Object.keys(Deepak[0]).map((key) => ({
    field: key,
    header: key.charAt(0).toUpperCase() + key.slice(1), // Capitalize first letter
  }));

//   useEffect(() => {
//     setdataTable(tableData);
//   }, []);

  return (
    <>
      <div className="inner-wrapper">
        <Header />
        <div className="content-wrapper">
          <div className="sidebar-menu">
            <MenuSidebar />
          </div>
          <div className="main-content">
            <div className="card">
              <DataTable value={tableData}>
                {columns.map((col) => (
                  <Column
                    key={col.field}
                    field={col.field}
                    header={col.header}
                  />
                ))}
              </DataTable>
              {/* <DataTable value={dataTable} tableStyle={{ minWidth: "50rem" }}>
                {columns.map((col, i) => (
                  <Column
                    key={col.field}
                    body={(rowData) =>
                        col.name === "action" ? col.cell(rowData) : rowData[col.label]
                      }
                    field={col.field}
                    header={col.header}
                  />
                ))}
              </DataTable> */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
